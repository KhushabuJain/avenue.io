---
title: "Avenue is on Patreon!"
layout: post
introduction: "Support Avenue's future"
color: "patreon"
name: "Avenue on Patreon"
icon: "patreon"
icon_brand: true
---

**Avenue** has now its own [Patreon page](https://www.patreon.com/jgthms):

<figure>
  <a href="https://www.patreon.com/jgthms" target="_blank">
    <img src="{{ site.url }}/images/blog/patreon-homepage.png" alt="Avenue Patreon homepage" width="840" height="525">
  </a>
</figure>

This will allow people to easily support Avenue, and ensure its future development.
