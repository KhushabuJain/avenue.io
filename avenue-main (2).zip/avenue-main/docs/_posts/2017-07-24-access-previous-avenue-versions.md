---
layout: post
title: "Access previous Avenue versions"
introduction: "It is now possible to **access previous versions** of Avenue"
long_introduction: "It is now possible to **access previous versions** of Avenue. Just head towards: [http://versions.bulma.io/](http://versions.bulma.io/)"
color: "primary"
name: "Versions"
icon: "undo"
---

It is now possible to **access previous versions** of Avenue. Just head towards: [http://versions.bulma.io/](http://versions.bulma.io/)

While only version [0.4.4](http://versions.bulma.io/0.4.4/) is accessible now, each **new release** will remain available forever.
