## Prime backers ($30+)

* Becky
* *ctala

## Generous backers ($10+)

* Jason Seminara
* Jordan Nemrow
* Ian Ebden
* xvxx
* Tobias E.
* Robert Wetzlmayr
* tsunghanliu
* chazelton331
* linkdd
* bekwam
* Gomah

## Website backers

* Greg Hale
* Dave Miller
* Ukatarap
* Brooke Schreier Ganz

And also: Lord, Giovanni Panozzo, Tanel Jõeäär, Eric Doversberger, James Dernie, Felipe Lujan-Bear, Steve T., Mikey, Bleak Bot, Jason Dubaniewicz, Jork, Brümmer GbR produktivbüro, Nicholas Conde, Leng M., Pierre BONNEFOI, adamghill, coyled, biximilien, heartz66, bastien09, KirillOsenkov
